I=imread('coins.png');
figure 
imshow(I);
g=im2bw(I);
b=[ 0 0 0 1 0 0 0
  0 0 1 1 1 0 0
  0 1 1 1 1 1 0
  1 1 1 1 1 1 1
  0 1 1 1 1 1 0
  0 0 1 1 1 0 0
  0 0 0 1 0 0 0];
d=imdilate(g,b);
figure 
imshow(d);
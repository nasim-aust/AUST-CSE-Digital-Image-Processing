function [ y ] = find2x( x )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
y = 2.*x

end


a=5;
b=6;
c=a+b;
disp(c);
x=[0:30:360];
y=sin(x);
plot(x,y)
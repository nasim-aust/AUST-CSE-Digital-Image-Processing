A=imread('cameraman.png')
figure;imshow(A);
